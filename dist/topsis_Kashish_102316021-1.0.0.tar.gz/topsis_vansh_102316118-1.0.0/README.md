# TOPSIS - Technique for Order of Preference by Similarity to Ideal Solution

## Overview
TOPSIS is a multi-criteria decision-making technique that ranks alternatives based on their similarity to the ideal solution. This implementation provides a Python-based solution for applying TOPSIS to your decision-making problems.

## Installation
```bash
pip install -e .
```

## Usage

### Command Line
```bash
python -m topsis.topsis <input_file> <weights> <impacts> <output_file>
```

#### Parameters:
- `input_file`: Path to CSV file with data (first column: object names, remaining columns: criteria values)
- `weights`: Comma-separated weights for each criterion (e.g., "1,1,1,1,1")
- `impacts`: Comma-separated impacts for each criterion (e.g., "+,+,-,+,-" where + means benefit, - means cost)
- `output_file`: Path to output CSV file with results

#### Example:
```bash
python -m topsis.topsis data.csv "1,1,1,1,1" "+,+,-,+,+" result.csv
```

### Python Module
```python
from topsis import topsis

topsis("input.csv", [1, 1, 1, 1, 1], ['+', '+', '-', '+', '+'], "output.csv")
```

## Input File Format
- First column: Object/Alternative names
- Remaining columns: Criteria values (numeric)

Example `data.csv`:
```
Object,Criterion1,Criterion2,Criterion3,Criterion4,Criterion5
Option1,2,3,4,5,6
Option2,3,4,5,6,7
Option3,1,2,3,4,5
```

## Output
The output CSV file includes:
- All original data
- `Topsis Score`: The TOPSIS score for each alternative (0-1)
- `Rank`: Ranking of alternatives (1 = best)

## License
This project is licensed under the MIT License - see the LICENSE file for details.
